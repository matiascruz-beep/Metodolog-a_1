﻿/*
 * Created by SharpDevelop.
 * User: mati1
 * Date: 23/9/2025
 * Time: 20:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Practica_4
{
	/// <summary>
	/// Description of Iterable.
	/// </summary>
	/// 
	
	
	public interface Iterable
	{
		Iterador crearIterador();
	}
}
