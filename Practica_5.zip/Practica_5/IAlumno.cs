﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_4
{
    internal interface IAlumno
    {
        string Nombre { get; set; }
        int ResponderPregunta(int pregunta);
    }
}
